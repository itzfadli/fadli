# Meezd Media

Official repo: https://github.com/ccocot/Instagram-Tools.git

Thank's To https://github.com/huttarichard/instagram-private-api For API

Isinya : 
- Botlike ( Lu nge-like foto-foto following lu, biar keliatan aktif kali)
- Delete All Photo
- FAH ( Target nya menggunakan HASHTAG)
- FFT ( Target nye menggunakan ORANG)
- FLA ( Target nya menggunakan  LOCATION)
- FLM (Target nya menggunakan FOTO)
- Unfollow All Following
- Unfollow Not Followback

Cara Install : 
- git clone https://github.com/beenatural/igv2.git
- cd igv2
- npm install or yarn install

How To Run :
- node fftauto.js

input your username, password, target, comment and delay in ms ( 1s = 1000ms )
